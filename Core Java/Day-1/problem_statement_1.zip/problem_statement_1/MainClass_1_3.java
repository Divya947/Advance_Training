package com.problem_statement_1;

public class MainClass_1_3 {
	public void createBooks() {
		Book_1_3 b[] = new Book_1_3[2];		 
	      b[0] = new Book_1_3("Java Programing ", 350.50);
	      b[1] = new Book_1_3("Let Us C", 200.00);
	      for(int i = 0; i<b.length; i++) {
		         b[i].display();
		         System.out.println(" ");
	      }
	    
	      }
	
	public void showBooks() {
		  	createBooks();
		
	}
	public static void main(String args[])  {
	    MainClass_1_3 c1 = new MainClass_1_3();  
		c1.showBooks();
	   
	      }
	   }