package com.problem_statement_3;
	public abstract class Instrument_3_1
	{
	public abstract void Play();
	}